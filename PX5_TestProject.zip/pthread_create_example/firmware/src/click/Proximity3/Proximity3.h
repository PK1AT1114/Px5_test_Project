/*------------------------------------------------------------------------------*/
/* Copyright 2020, Microchip Technology Inc. and its subsidiaries.              */
/*                                                                              */
/* Redistribution and use in source and binary forms, with or without           */
/* modification, are permitted provided that the following conditions are met:  */
/*                                                                              */
/* 1. Redistributions of source code must retain the above copyright notice,    */
/*    this list of conditions and the following disclaimer.                     */
/*                                                                              */
/* 2. Redistributions in binary form must reproduce the above copyright notice, */
/*    this list of conditions and the following disclaimer in the documentation */
/*    and/or other materials provided with the distribution.                    */
/*                                                                              */
/* 3. Neither the name of the copyright holder nor the names of its             */
/*    contributors may be used to endorse or promote products derived from      */
/*    this software without specific prior written permission.                  */
/*                                                                              */
/* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"  */
/* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE    */
/* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE   */
/* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE    */
/* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,             */
/* OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF      */
/* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;                 */
/* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,     */
/* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR      */
/* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,               */
/* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                           */
/*------------------------------------------------------------------------------*/

#ifndef VCNL4200_H_INCLUDED
#define VCNL4200_H_INCLUDED

/******************************************************************************
 *  VCNL4200 senor is I2C based. (NOTE: Repeat Start is used for read)
 ******************************************************************************/
/******************************************************************************
 *  INCLUDES
 ******************************************************************************/
#include "stdint.h"

/******************************************************************************
 *  FUNCTION DECLARATIONS
 ******************************************************************************/
void vcnl4200_proximityinit(void);
void vcnl4200_ambientinit(void);
void vcnl4200_ambient_service(void);
void vcnl4200_proximity_service(void);
uint16_t vcnl4200_UpdateProximityValue(void);
uint16_t vcnl4200_UpdateambientValue(void);
uint8_t vcnl4200_ambient_task(void);
uint8_t vcnl4200_proximity_task(void);

uint16_t vcnl4200_get_proximity(void);
uint16_t vcnl4200_get_ambience(void);

#endif /* VCNL4200_H_INCLUDED */

/*------------------------------ End of File ----------------------------------*/